
<!doctype html>
<html>
    <head>
        <title>ARTICLES</title>
        <link rel="stylesheet" href="css/style.css">   
    </head>
    <body>

        <?php include_once(dirname(__FILE__) . '/views/page_article.php'); ?>
        
        <!-- Optional JavaScript -->
        <script src="js/jquery-3.2.1.min.js"></script>
	    <script src="js/jquery.form.js"></script>
	    <script src="js/bootstrap.min.js"></script>
        
    </body>
</html>