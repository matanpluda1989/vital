<?php

    include_once 'db_connnection.php';
    
    session_start();
    $dbName = $_SESSION["DB_NAME"];

    //Retrieving and displaying the relevant article
    getSpecificArticle($dbName);
?>

<?php

    function getSpecificArticle($dbName) {
        
        //Create connection to DB
        $conn = OpenCon($dbName);
      
        $id = $_GET['content'];   

        try {
            //Query for get the content and title of article by id
            $stmt = $conn->prepare("SELECT name, content FROM articles WHERE id=?");
            $stmt->execute(array($id)); 
            $article = $stmt->fetch();
        }
        catch (Exception $e) {
            echo 'Caught exception: ',  $e->getMessage(), "\n";
        }

        
        $title = $article["name"];
        $text = $article["content"];
        $text = str_replace("\r\n\r\n", "<br>", $text);
        
        //Get the text's direction by language 
        $textdir = getDir($text[0]);

        echo "<h1 id='title'>" . $title . "</h2> <br>";
        echo "<div id='text' dir=$textdir >"  . $text . "</div>";

        //Close the connection
        CloseCon($conn); 
    }

    function getDir($ch) {
        if (preg_match('/[א-ת]/',$ch)) {
            return "rtl";
        }
        return "lft";
    }    
    
?>            
            