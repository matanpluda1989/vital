<?php    
    
    include_once 'db_connnection.php';

    $dbName = constant("db");

    session_start();
    $_SESSION["DB_NAME"] = $dbName;

    //Create list of articles
    getArticles($dbName);            
    
?>

<?php 

    function getArticles($dbName) {
 
        //Create connection to DB      
        $conn = OpenCon($dbName);   

        try {
            $stmt = $conn->prepare("SELECT id, name FROM articles");
            $stmt->execute();
            
            // output data of each row
            while($row = $stmt->fetch()) {  
                $id = $row["id"];                 
                echo "<tr><th><a id='rowTbl' href='article.php?content=$id'>" . $row["name"] . "</a></th></tr>";
            }
        }
        catch (Exception $e) {
            echo 'Caught exception: ',  $e->getMessage(), "\n";
        }
 
        //Close the connection
        CloseCon($conn);  
 
    }
?>