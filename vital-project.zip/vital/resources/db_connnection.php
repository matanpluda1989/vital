<?php
    
    function OpenCon($dbName)
    {

        include_once 'config.php';     

        try {
            $conn = new PDO(DB_TYPE . ":host=" .DB_SERVER . ";dbname=$dbName", DB_USER, DB_PASS);
            
            // set the PDO error mode to exception
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        }
        catch(PDOException $e) {
            die("Connection failed: " . $e->getMessage());
        }
        
        return $conn;    

    }
 
    function CloseCon($conn)
    {
        $conn = null;
    }
    
?>



