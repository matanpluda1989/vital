<?php

    const DB_TYPE = 'mysql';
    const DB_SERVER = 'localhost';
    const DB_USER = 'username';
    const DB_PASS = 'password'; 

?>
