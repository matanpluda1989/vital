<header>
    <h1 id="h1">אינדקס מאמרים</h2>
</header>