<footer class="footer-area section_gap">
    <div id="footer">
        <br><br><br>
        <span>&copy;<a href=#> מאמרי פלודה בע"מ </a></span>
    </div>
</footer>