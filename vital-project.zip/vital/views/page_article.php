
<?php include_once(dirname(__DIR__) . '/resources/_article.php'); ?>
            
<div id="rtnBtn">
    <a href='index.php'> <br> חזרה לעמוד ראשי </a>
</div>

