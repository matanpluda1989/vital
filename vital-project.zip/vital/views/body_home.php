<section>
    <table>
        <tr id="h2">
            <th>שם מאמר</th>
        </tr>
            
        <?php include_once(dirname(__DIR__) . '/resources/_index.php'); ?>                  
                
    </table>
</section>