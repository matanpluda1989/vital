<?php
    $dbName = "article";
    define("db", $dbName); 
?>

<!doctype html>
<html>
    <head>
        <title>ARTICLES</title>
        <link rel="stylesheet" href="css/style.css">  
    </head>
    <body class="container">

        <?php include_once(dirname(__FILE__) . '/views/header_home.php'); ?>

        <?php include_once(dirname(__FILE__) . '/views/body_home.php'); ?>

        <?php include_once(dirname(__FILE__) . '/views/footer_home.php'); ?>

        <!-- Optional JavaScript -->
        <script src="js/jquery-3.2.1.min.js"></script>
	    <script src="js/jquery.form.js"></script>
	    <script src="js/bootstrap.min.js"></script>
        
    </body>

    
</html>